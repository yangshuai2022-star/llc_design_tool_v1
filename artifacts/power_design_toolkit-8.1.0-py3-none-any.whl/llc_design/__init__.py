"""LLC half/full-bridge resonant converter design and optimization tool."""

__version__ = "8.1.0"
